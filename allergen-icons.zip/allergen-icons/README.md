Thanks for checking out these allergen icons!

This project is licensed under Creative Commons Attribution-ShareAlike 4.0 International Public License: https://creativecommons.org/licenses/by-sa/4.0/legalcode

🐟 Team YupGup
twitter.com/helloyupgup
